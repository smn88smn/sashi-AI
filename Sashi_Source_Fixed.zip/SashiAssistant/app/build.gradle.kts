import java.net.URL
import java.util.zip.ZipInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sashi.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sashi.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")

    // Compose
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.8.2")

    // Lifecycle / Coroutines
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // Vosk (آفلاین) — JNA باید به صورت aar باشد
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
}

// ---------------------------------------------------------------------------
// دانلود خودکار مدل فارسی Vosk داخل assets/model-fa (فقط اگر وجود نداشته باشد)
// برای دانلود دستی: همین پوشه را خودتان پر کنید (باید داخلش am/ conf/ graph/ ... باشد)
// ---------------------------------------------------------------------------
val voskModelUrl = "https://alphacephei.com/vosk/models/vosk-model-small-fa-0.42.zip"
val voskModelDir = layout.projectDirectory.dir("src/main/assets/model-fa").asFile

val downloadVoskModel by tasks.registering {
    onlyIf { !File(voskModelDir, "am").isDirectory }
    doLast {
        val zipFile = File(temporaryDir, "vosk-model-fa.zip")
        logger.lifecycle("Downloading Vosk Persian model: $voskModelUrl")
        URL(voskModelUrl).openStream().use { input ->
            zipFile.outputStream().use { output -> input.copyTo(output) }
        }
        voskModelDir.deleteRecursively()
        voskModelDir.mkdirs()
        val rootCanonical = voskModelDir.canonicalPath
        ZipInputStream(zipFile.inputStream()).use { zin ->
            var entry = zin.nextEntry
            while (entry != null) {
                // پوشه‌ی بالاترین سطح زیپ (vosk-model-small-fa-0.42/) را حذف می‌کنیم
                val relative = entry.name.substringAfter('/', "")
                if (relative.isNotEmpty()) {
                    val out = File(voskModelDir, relative)
                    require(out.canonicalPath.startsWith(rootCanonical)) { "Bad zip entry: ${entry.name}" }
                    if (entry.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile.mkdirs()
                        out.outputStream().use { zin.copyTo(it) }
                    }
                }
                zin.closeEntry()
                entry = zin.nextEntry
            }
        }
        zipFile.delete()
        logger.lifecycle("Model ready at $voskModelDir")
    }
}

tasks.named("preBuild") { dependsOn(downloadVoskModel) }
