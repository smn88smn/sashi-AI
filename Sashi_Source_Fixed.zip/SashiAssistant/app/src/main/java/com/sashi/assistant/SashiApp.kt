package com.sashi.assistant

import android.app.Application
import com.sashi.assistant.utils.AppLauncher
import com.sashi.assistant.voice.TtsHelper
import com.sashi.assistant.voice.VoskHelper

class SashiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        TtsHelper.init(this)
        AppLauncher.refreshAsync(this)   // روی ترد پس‌زمینه
        VoskHelper.preload(this)         // مدل از قبل آماده می‌شود تا دستیار سریع باز شود
    }
}
