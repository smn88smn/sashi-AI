package com.sashi.assistant.service

import android.app.admin.DeviceAdminReceiver

/** فقط برای مجوز قفل صفحه. هیچ دسترسی دیگری (پاک کردن اطلاعات، رمز و ...) درخواست نمی‌شود. */
class SashiAdminReceiver : DeviceAdminReceiver()
