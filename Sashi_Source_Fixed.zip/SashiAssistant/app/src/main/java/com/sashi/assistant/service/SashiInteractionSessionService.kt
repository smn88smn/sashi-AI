package com.sashi.assistant.service

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.util.Log
import com.sashi.assistant.ui.AssistantActivity
import java.lang.ref.WeakReference

class SashiInteractionSessionService : VoiceInteractionSessionService() {

    override fun onNewSession(args: Bundle?): VoiceInteractionSession = SashiSession(this)

    private class SashiSession(private val service: SashiInteractionSessionService) :
        VoiceInteractionSession(service) {

        override fun onCreate() {
            super.onCreate()
            setUiEnabled(false) // خود session رابط کاربری ندارد؛ UI در AssistantActivity است
        }

        override fun onShow(args: Bundle?, showFlags: Int) {
            super.onShow(args, showFlags)
            current = WeakReference(this)
            val intent = Intent(service, AssistantActivity::class.java)
            try {
                startAssistantActivity(intent)
            } catch (e: Exception) {
                Log.w("Sashi", "startAssistantActivity failed, falling back", e)
                try {
                    service.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e2: Exception) {
                    Log.e("Sashi", "Cannot start AssistantActivity", e2)
                    hide()
                }
            }
        }

        override fun onDestroy() {
            if (current?.get() === this) current = null
            super.onDestroy()
        }
    }

    companion object {
        @Volatile private var current: WeakReference<VoiceInteractionSession>? = null

        /** وقتی AssistantActivity بسته شد صدا زده می‌شود تا session سیستم هم بسته شود. */
        fun dismissSession() {
            val s = current?.get() ?: return
            Handler(Looper.getMainLooper()).post {
                try { s.hide() } catch (_: Exception) {}
            }
        }
    }
}
