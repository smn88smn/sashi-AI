package com.sashi.assistant.service

import android.service.voice.VoiceInteractionService
import android.util.Log

class SashiVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        Log.d("Sashi", "Voice interaction service ready")
    }
}
