package com.sashi.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.sashi.assistant.service.SashiInteractionSessionService
import com.sashi.assistant.ui.theme.SashiTheme
import kotlinx.coroutines.launch

class AssistantActivity : ComponentActivity() {

    private val vm: AssistantViewModel by viewModels()
    private var awaitingPermission = false

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            awaitingPermission = false
            if (granted) vm.start() else vm.onMicDenied()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        @Suppress("DEPRECATION")
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                val lp = window.attributes
                lp.blurBehindRadius = 40
                window.attributes = lp
            } catch (_: Exception) { }
        }

        setContent {
            SashiTheme {
                AssistantScreen(vm = vm, onDismiss = {
                    vm.cancelAll()
                    finish()
                })
            }
        }

        // بسته شدن بعد از جواب (حتی اگر Activity پشت اپ دیگری باشد)
        lifecycleScope.launch { vm.closeEvents.collect { finish() } }

        startOrAskPermission()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (hasMic()) vm.restart() else startOrAskPermission()
    }

    private fun hasMic() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    private fun startOrAskPermission() {
        if (hasMic()) vm.start()
        else if (!awaitingPermission) {
            awaitingPermission = true
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    override fun onStop() {
        super.onStop()
        // اگر هنوز در حال گوش دادن بود و کاربر رفت (Home/Recents) میکروفون را رها کن و ببند
        if (!isChangingConfigurations && !awaitingPermission && vm.onActivityStopped()) finish()
    }

    override fun onDestroy() {
        if (isFinishing) {
            vm.cancelAll()
            SashiInteractionSessionService.dismissSession()
        }
        super.onDestroy()
    }
}
