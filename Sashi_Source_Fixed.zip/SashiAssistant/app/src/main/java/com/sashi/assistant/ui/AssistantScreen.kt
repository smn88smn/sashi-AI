package com.sashi.assistant.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

private val Cyan = Color(0xFF00D4FF)
private val Violet = Color(0xFFA855F7)
private val Green = Color(0xFF22C55E)
private val Red = Color(0xFFFF647C)

@Composable
fun AssistantScreen(vm: AssistantViewModel, onDismiss: () -> Unit) {
    val state by vm.state.collectAsState()
    val level by vm.level.collectAsState()
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() },
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = slideInVertically(tween(450, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(300))
            ) {
                GlassCard(state, level)
            }
        }
    }
}

@Composable
private fun GlassCard(state: AssistantUiState, level: Float) {
    val target = when (state) {
        is AssistantUiState.Success -> Green
        is AssistantUiState.Error -> Red
        is AssistantUiState.Processing -> Violet
        else -> Cyan
    }
    val accent by animateColorAsState(target, tween(400), label = "accent")
    val shape = RoundedCornerShape(32.dp)

    Box(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(14.dp)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xE61A2033), Color(0xF20B0F19))))
            .border(
                1.dp,
                Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.35f), Color.White.copy(alpha = 0.05f))),
                shape
            )
            // کلیک روی خود کارت نباید دستیار را ببندد
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
    ) {
        Aurora(accent, Modifier.matchParentSize())
        Column(
            Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 24.dp, top = 14.dp, bottom = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier
                    .width(40.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.25f))
            )
            Spacer(Modifier.height(14.dp))
            Text("SASHI", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
            Spacer(Modifier.height(16.dp))
            Orb(state, level, accent)
            Spacer(Modifier.height(14.dp))
            Waveform(level, active = state is AssistantUiState.Listening, color = accent)
            Spacer(Modifier.height(14.dp))
            StatusTexts(state)
        }
    }
}

@Composable
private fun StatusTexts(state: AssistantUiState) {
    val (title, sub) = when (state) {
        is AssistantUiState.LoadingModel -> "در حال آماده‌سازی…" to ""
        is AssistantUiState.Listening ->
            if (state.partial.isBlank()) "دارم گوش می‌دم…" to "مثلاً: «اینستاگرام را باز کن»"
            else state.partial to ""
        is AssistantUiState.Processing -> state.heard to "در حال انجام…"
        is AssistantUiState.Success -> state.message to "«${state.heard}»"
        is AssistantUiState.Error -> state.message to (if (state.heard.isBlank()) "" else "«${state.heard}»")
    }
    Text(
        title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
        textAlign = TextAlign.Center, modifier = Modifier.heightIn(min = 26.dp)
    )
    if (sub.isNotBlank()) {
        Spacer(Modifier.height(6.dp))
        Text(sub, color = Color(0xFFB7C4D8), fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun Aurora(color: Color, modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Reverse), label = "p"
    )
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val c1 = Offset(w * (0.15f + 0.6f * p), h * 0.12f)
        val c2 = Offset(w * (0.85f - 0.6f * p), h * 0.95f)
        drawCircle(
            Brush.radialGradient(listOf(color.copy(alpha = 0.28f), Color.Transparent), center = c1, radius = w * 0.75f),
            radius = w * 0.75f, center = c1
        )
        drawCircle(
            Brush.radialGradient(listOf(Violet.copy(alpha = 0.20f), Color.Transparent), center = c2, radius = w * 0.7f),
            radius = w * 0.7f, center = c2
        )
    }
}

@Composable
private fun Orb(state: AssistantUiState, level: Float, accent: Color) {
    val t = rememberInfiniteTransition(label = "orb")
    val angle by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "angle"
    )
    val dots by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "dots"
    )
    val listening = state is AssistantUiState.Listening
    val scale by animateFloatAsState(if (listening) 1f + level * 0.35f else 1f, tween(90), label = "scale")

    Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(112.dp).scale(scale)) {
            val c = center
            drawCircle(
                Brush.radialGradient(listOf(accent.copy(alpha = 0.35f), Color.Transparent), center = c, radius = size.minDimension / 2),
                radius = size.minDimension / 2, center = c
            )
            val ringR = size.minDimension * 0.36f
            rotate(angle, pivot = c) {
                drawCircle(
                    Brush.sweepGradient(listOf(accent, Violet, accent.copy(alpha = 0.1f), accent), center = c),
                    radius = ringR, center = c, style = Stroke(width = 4.dp.toPx())
                )
            }
            drawCircle(
                Brush.radialGradient(listOf(accent, lerp(accent, Color.Black, 0.45f)), center = c, radius = ringR),
                radius = ringR - 6.dp.toPx(), center = c
            )
        }
        Canvas(Modifier.size(40.dp)) {
            when (state) {
                is AssistantUiState.Success -> drawCheck()
                is AssistantUiState.Error -> drawBang()
                is AssistantUiState.Processing -> drawDots(dots)
                is AssistantUiState.LoadingModel -> drawDots(dots)
                is AssistantUiState.Listening -> drawMic()
            }
        }
    }
}

private fun DrawScope.drawMic() {
    val u = size.minDimension / 10f
    val w = Color.White
    drawRoundRect(w, Offset(3.5f * u, 0.8f * u), Size(3f * u, 5f * u), CornerRadius(1.5f * u))
    drawArc(
        w, 0f, 180f, false, Offset(2.4f * u, 2.6f * u), Size(5.2f * u, 5f * u),
        style = Stroke(0.6f * u, cap = StrokeCap.Round)
    )
    drawLine(w, Offset(5f * u, 7.6f * u), Offset(5f * u, 9.2f * u), 0.6f * u, StrokeCap.Round)
    drawLine(w, Offset(3.6f * u, 9.2f * u), Offset(6.4f * u, 9.2f * u), 0.6f * u, StrokeCap.Round)
}

private fun DrawScope.drawCheck() {
    val u = size.minDimension / 10f
    val p = Path().apply {
        moveTo(2.3f * u, 5.3f * u); lineTo(4.3f * u, 7.3f * u); lineTo(7.8f * u, 3f * u)
    }
    drawPath(p, Color.White, style = Stroke(0.95f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.drawBang() {
    val u = size.minDimension / 10f
    drawLine(Color.White, Offset(5f * u, 2f * u), Offset(5f * u, 5.8f * u), 0.95f * u, StrokeCap.Round)
    drawCircle(Color.White, 0.55f * u, Offset(5f * u, 8f * u))
}

private fun DrawScope.drawDots(phase: Float) {
    val u = size.minDimension / 10f
    for (i in 0..2) {
        val a = 0.3f + 0.7f * ((phase + i / 3f) % 1f)
        drawCircle(Color.White.copy(alpha = a), 0.7f * u, Offset((2.3f + 2.7f * i) * u, 5f * u))
    }
}

@Composable
private fun Waveform(level: Float, active: Boolean, color: Color) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "phase"
    )
    val lvl by animateFloatAsState(if (active) maxOf(level, 0.08f) else 0.04f, tween(80), label = "lvl")
    val bars = 30
    Canvas(Modifier.fillMaxWidth().height(46.dp)) {
        val gap = 4.dp.toPx()
        val barW = (size.width - gap * (bars - 1)) / bars
        val minH = 4.dp.toPx()
        for (i in 0 until bars) {
            val shape = sin(PI * (i + 0.5) / bars).toFloat()
            val wobble = 0.55f + 0.45f * abs(sin(2 * PI * (phase + i / bars.toFloat() * 1.5))).toFloat()
            val h = minH + (size.height - minH) * (lvl * shape * wobble).coerceIn(0f, 1f)
            val x = i * (barW + gap)
            drawRoundRect(
                lerp(color, Violet, i / (bars - 1f)).copy(alpha = if (active) 0.95f else 0.45f),
                Offset(x, (size.height - h) / 2f), Size(barW, h), CornerRadius(barW / 2f)
            )
        }
    }
}
