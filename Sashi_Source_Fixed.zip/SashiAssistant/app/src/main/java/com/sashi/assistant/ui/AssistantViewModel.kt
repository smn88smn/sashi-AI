package com.sashi.assistant.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sashi.assistant.utils.CommandParser
import com.sashi.assistant.voice.TtsHelper
import com.sashi.assistant.voice.VoskHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

sealed class AssistantUiState {
    object LoadingModel : AssistantUiState()
    data class Listening(val partial: String = "") : AssistantUiState()
    data class Processing(val heard: String) : AssistantUiState()
    data class Success(val heard: String, val message: String) : AssistantUiState()
    data class Error(val message: String, val heard: String = "") : AssistantUiState()
}

class AssistantViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow<AssistantUiState>(AssistantUiState.LoadingModel)
    val state: StateFlow<AssistantUiState> = _state.asStateFlow()

    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    private val closeChannel = Channel<Unit>(Channel.CONFLATED)
    val closeEvents = closeChannel.receiveAsFlow()

    private var session: VoskHelper.ListeningSession? = null
    private var started = false
    private var generation = 0

    /** فقط یک بار اجرا می‌شود (با چرخش صفحه دوباره شروع نمی‌شود). */
    fun start() {
        if (started) return
        started = true
        begin()
    }

    /** وقتی دستیار دوباره صدا زده شد و Activity از قبل باز بود. */
    fun restart() {
        cancelAll()
        started = true
        begin()
    }

    private fun begin() {
        val gen = ++generation
        _state.value = AssistantUiState.LoadingModel
        viewModelScope.launch {
            VoskHelper.preload(getApplication())
            val ms = withTimeoutOrNull(60_000) {
                VoskHelper.modelState.first {
                    it is VoskHelper.ModelState.Ready || it is VoskHelper.ModelState.Failed
                }
            }
            if (gen != generation) return@launch
            when (ms) {
                is VoskHelper.ModelState.Ready -> beginListening(gen)
                is VoskHelper.ModelState.Failed ->
                    finishWith(AssistantUiState.Error("مدل فارسی پیدا نشد یا بارگذاری نشد"), "مدل تشخیص گفتار آماده نیست")
                else ->
                    finishWith(AssistantUiState.Error("بارگذاری مدل خیلی طول کشید"), "بارگذاری مدل طول کشید")
            }
        }
    }

    private fun beginListening(gen: Int) {
        _state.value = AssistantUiState.Listening()
        _level.value = 0f
        val s = VoskHelper.startListening(object : VoskHelper.Listener {
            override fun onLevel(level: Float) { if (gen == generation) _level.value = level }
            override fun onPartial(text: String) {
                if (gen == generation) _state.value = AssistantUiState.Listening(text)
            }
            override fun onResult(text: String) { if (gen == generation) handleResult(text, gen) }
            override fun onNoSpeech() {
                if (gen == generation) finishWith(AssistantUiState.Error("صدایی نشنیدم"), "صدایی نشنیدم")
            }
            override fun onError(message: String) {
                if (gen == generation) finishWith(AssistantUiState.Error(message), "مشکلی پیش اومد")
            }
        })
        if (s == null) finishWith(AssistantUiState.Error("مدل گفتار آماده نیست"), "مدل گفتار آماده نیست")
        else session = s
    }

    private fun handleResult(text: String, gen: Int) {
        session = null
        _level.value = 0f
        _state.value = AssistantUiState.Processing(text)
        viewModelScope.launch {
            delay(300) // تا وضعیت «در حال انجام» دیده شود
            val res = withContext(Dispatchers.Default) {
                try {
                    CommandParser.execute(getApplication(), CommandParser.parse(text))
                } catch (t: Throwable) {
                    com.sashi.assistant.utils.ExecResult("مشکلی پیش اومد", false)
                }
            }
            if (gen != generation) return@launch
            val ui = if (res.success) AssistantUiState.Success(text, res.message)
            else AssistantUiState.Error(res.message, text)
            finishWith(ui, res.message, res.postAction)
        }
    }

    private fun finishWith(ui: AssistantUiState, speech: String, postAction: (() -> Unit)? = null) {
        session?.cancel(); session = null
        _level.value = 0f
        _state.value = ui
        val gen = generation
        TtsHelper.speak(speech) {
            viewModelScope.launch {
                postAction?.let { withContext(Dispatchers.Default) { it() } }
                delay(450)
                if (gen == generation) closeChannel.trySend(Unit)
            }
        }
    }

    fun onMicDenied() {
        finishWith(AssistantUiState.Error("برای کار کردن، مجوز میکروفون لازمه"), "مجوز میکروفون لازمه")
    }

    /** true یعنی Activity باید بسته شود (هنوز در حال گوش دادن بوده و از جلوی صفحه رفته). */
    fun onActivityStopped(): Boolean {
        val s = _state.value
        return if (s is AssistantUiState.LoadingModel || s is AssistantUiState.Listening) {
            cancelAll(); true
        } else false
    }

    fun cancelAll() {
        generation++
        session?.cancel(); session = null
        TtsHelper.stop()
        _level.value = 0f
    }

    override fun onCleared() {
        session?.cancel(); session = null
        super.onCleared()
    }
}
