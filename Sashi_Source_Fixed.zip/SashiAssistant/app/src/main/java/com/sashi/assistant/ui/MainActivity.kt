package com.sashi.assistant.ui

import android.Manifest
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.sashi.assistant.ui.theme.SashiTheme
import com.sashi.assistant.utils.ScreenLocker
import com.sashi.assistant.voice.TtsHelper
import com.sashi.assistant.voice.VoskHelper

/** صفحه‌ی راه‌اندازی: مجوزها، انتخاب دستیار پیش‌فرض، وضعیت مدل و TTS، تست. */
class MainActivity : ComponentActivity() {

    private var refresh by mutableIntStateOf(0)

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refresh++
    }
    private val adminResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        refresh++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        VoskHelper.preload(this)
        setContent {
            SashiTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    SetupScreen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh++
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun isDefaultAssistant(): Boolean {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java)
            try {
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_ASSISTANT) &&
                    rm.isRoleHeld(RoleManager.ROLE_ASSISTANT)
                ) return true
            } catch (_: Exception) { }
        }
        val v = Settings.Secure.getString(contentResolver, "assistant") ?: return false
        return v.startsWith(packageName)
    }

    private fun tryStart(vararg intents: Intent) {
        for (i in intents) {
            try { startActivity(i); return } catch (_: ActivityNotFoundException) { } catch (_: SecurityException) { }
        }
    }

    private fun appDetails() = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))

    @Composable
    private fun SetupScreen() {
        @Suppress("UNUSED_VARIABLE") val tick = refresh // با هر refresh دوباره محاسبه شود
        val modelState by VoskHelper.modelState.collectAsState()
        val ttsStatus by TtsHelper.status.collectAsState()

        val hasModel = VoskHelper.hasModelAsset(this)
        val mic = granted(Manifest.permission.RECORD_AUDIO)
        val call = granted(Manifest.permission.CALL_PHONE)
        val contacts = granted(Manifest.permission.READ_CONTACTS)
        val isAssistant = isDefaultAssistant()
        val adminOn = ScreenLocker.isActive(this)

        Column(
            Modifier
                .fillMaxSize()
                .background(Color(0xFF0B0F19))
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("ساشی", color = Color(0xFF00D4FF), fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("دستیار صوتی فارسی آفلاین", color = Color(0xFFB7C4D8), fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))

            Row1(
                "مدل تشخیص گفتار فارسی",
                when {
                    !hasModel -> Status.BAD to "داخل APK نیست (build را دوباره بزنید)"
                    modelState is VoskHelper.ModelState.Ready -> Status.OK to "بارگذاری شد"
                    modelState is VoskHelper.ModelState.Failed -> Status.BAD to
                        "خطا: " + (modelState as VoskHelper.ModelState.Failed).reason
                    else -> Status.WAIT to "در حال بارگذاری (بار اول کمی طول می‌کشد)…"
                }
            )

            Row1("میکروفون", if (mic) Status.OK to "داده شد" else Status.BAD to "لازم است")
            Row1("تماس مستقیم", if (call) Status.OK to "داده شد" else Status.WARN to "بدون آن فقط شماره‌گیر باز می‌شود")
            Row1("مخاطبین (زنگ زدن با اسم)", if (contacts) Status.OK to "داده شد" else Status.WARN to "بدون آن فقط با شماره می‌شود")
            if (!(mic && call && contacts)) {
                Button(onClick = {
                    permissions.launch(
                        arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
                    )
                }, modifier = Modifier.fillMaxWidth()) { Text("درخواست مجوزها") }
            }

            Row1(
                "قفل کردن صفحه با صدا",
                if (adminOn) Status.OK to "فعال" else Status.WARN to "فعال نیست"
            )
            if (!adminOn) {
                Button(
                    onClick = { adminResult.launch(ScreenLocker.requestIntent(this@MainActivity)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("فعال‌سازی قفل صفحه") }
            } else {
                OutlinedButton(
                    onClick = { ScreenLocker.deactivate(this@MainActivity); refresh++ },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("غیرفعال کردن (لازم برای حذف برنامه)") }
            }

            Row1(
                "دستیار پیش‌فرض",
                if (isAssistant) Status.OK to "ساشی انتخاب شده" else Status.BAD to "هنوز انتخاب نشده"
            )
            Button(onClick = {
                tryStart(
                    Intent(Settings.ACTION_VOICE_INPUT_SETTINGS),
                    Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
                    Intent(Settings.ACTION_SETTINGS)
                )
            }, modifier = Modifier.fillMaxWidth()) { Text("باز کردن تنظیمات دستیار پیش‌فرض") }

            Row1(
                "صدای فارسی (TTS)",
                when (ttsStatus) {
                    TtsHelper.Status.PERSIAN_OK -> Status.OK to "آماده"
                    TtsHelper.Status.CHECKING -> Status.WAIT to "در حال بررسی…"
                    TtsHelper.Status.PERSIAN_MISSING -> Status.BAD to "موتور TTS فعلی فارسی ندارد؛ جواب صوتی پخش نمی‌شود"
                    TtsHelper.Status.ENGINE_FAILED -> Status.BAD to "موتور TTS در دسترس نیست"
                }
            )
            OutlinedButton(onClick = {
                tryStart(
                    Intent("com.android.settings.TTS_SETTINGS"),
                    Intent(Settings.ACTION_SETTINGS)
                )
            }, modifier = Modifier.fillMaxWidth()) { Text("تنظیمات خروجی گفتار (TTS)") }

            Text("مخصوص شیائومی (MIUI / HyperOS)", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            OutlinedButton(onClick = {
                tryStart(
                    Intent().setComponent(
                        ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
                    ),
                    appDetails()
                )
            }, modifier = Modifier.fillMaxWidth()) { Text("شروع خودکار (Autostart) را روشن کن") }
            OutlinedButton(onClick = {
                tryStart(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), appDetails())
            }, modifier = Modifier.fillMaxWidth()) { Text("بدون محدودیت باتری") }

            Spacer(Modifier.height(4.dp))
            Button(
                onClick = { startActivity(Intent(this@MainActivity, AssistantActivity::class.java)) },
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) { Text("تست دستیار", fontSize = 16.sp) }
            Spacer(Modifier.height(24.dp))
        }
    }

    private enum class Status { OK, WARN, BAD, WAIT }

    @Composable
    private fun Row1(title: String, st: Pair<Status, String>) {
        val color = when (st.first) {
            Status.OK -> Color(0xFF22C55E)
            Status.WARN -> Color(0xFFF59E0B)
            Status.BAD -> Color(0xFFFF647C)
            Status.WAIT -> Color(0xFF00D4FF)
        }
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF151B2B))
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    when (st.first) { Status.OK -> "✓"; Status.WARN -> "!"; Status.BAD -> "✗"; Status.WAIT -> "…" },
                    color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.padding(horizontal = 6.dp))
                Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(st.second, color = color, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}
