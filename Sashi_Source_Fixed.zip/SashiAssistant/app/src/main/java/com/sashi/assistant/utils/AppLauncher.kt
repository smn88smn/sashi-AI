package com.sashi.assistant.utils

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat

object AppLauncher {

    private const val TAG = "Sashi"

    private data class AppEntry(val label: String, val norm: String, val pkg: String)
    private class AliasGroup(val names: List<String>, val targets: List<String>) {
        val normNames = names.map { TextNorm.normalize(it) }
    }

    @Volatile private var apps: List<AppEntry> = emptyList()

    // targets: اگر نقطه دارد = نام پکیج دقیق؛ در غیر این صورت = کلمه‌ای که داخل نام اپ جستجو می‌شود (انگلیسی/فارسی)
    private val aliasGroups: List<AliasGroup> = listOf(
        AliasGroup(listOf("اینستاگرام", "اینستا", "اینستگرام"), listOf("com.instagram.android", "instagram")),
        AliasGroup(listOf("تلگرام", "تلگرم"), listOf("org.telegram.messenger", "org.telegram.messenger.web", "telegram")),
        AliasGroup(listOf("واتساپ", "واتس اپ", "واتسپ", "واتس آپ"), listOf("com.whatsapp", "com.whatsapp.w4b", "whatsapp")),
        AliasGroup(listOf("یوتیوب", "یوتوب"), listOf("com.google.android.youtube", "youtube")),
        AliasGroup(listOf("کروم", "گوگل کروم"), listOf("com.android.chrome", "chrome")),
        AliasGroup(listOf("مرورگر", "وب گرد"), listOf("com.android.chrome", "com.mi.globalbrowser", "browser", "chrome")),
        AliasGroup(listOf("جیمیل", "جی میل", "ایمیل"), listOf("com.google.android.gm", "gmail")),
        AliasGroup(listOf("نقشه", "گوگل مپ", "نقشه گوگل", "مپ"), listOf("com.google.android.apps.maps", "maps")),
        AliasGroup(listOf("نشان"), listOf("neshan", "نشان")),
        AliasGroup(listOf("بلد"), listOf("balad", "بلد")),
        AliasGroup(listOf("ایتا"), listOf("eitaa", "ایتا")),
        AliasGroup(listOf("روبیکا"), listOf("rubika", "روبیکا")),
        AliasGroup(listOf("بله"), listOf("ir.nasim", "bale", "بله")),
        AliasGroup(listOf("اسنپ"), listOf("cab.snapp.passenger", "snapp", "اسنپ")),
        AliasGroup(listOf("تپسی"), listOf("taxi.tap30.passenger", "tapsi", "تپسی")),
        AliasGroup(listOf("دیجی کالا", "دیجیکالا"), listOf("digikala", "دیجی")),
        AliasGroup(listOf("دیوار"), listOf("ir.divar", "divar", "دیوار")),
        AliasGroup(listOf("آپارات", "اپارات"), listOf("aparat", "آپارات", "اپارات")),
        AliasGroup(listOf("اسپاتیفای"), listOf("com.spotify.music", "spotify")),
        AliasGroup(listOf("نتفلیکس"), listOf("com.netflix.mediaclient", "netflix")),
        AliasGroup(listOf("تیک تاک", "تیکتاک"), listOf("com.zhiliaoapp.musically", "tiktok")),
        AliasGroup(listOf("توییتر", "تویتر", "ایکس"), listOf("com.twitter.android", "twitter")),
        AliasGroup(listOf("فیسبوک", "فیس بوک"), listOf("com.facebook.katana", "facebook")),
        AliasGroup(listOf("لینکدین"), listOf("com.linkedin.android", "linkedin")),
        AliasGroup(listOf("دیسکورد"), listOf("com.discord", "discord")),
        AliasGroup(listOf("زوم"), listOf("us.zoom.videomeetings", "zoom")),
        AliasGroup(listOf("پلی استور", "گوگل پلی", "پلی"), listOf("com.android.vending", "play store")),
        AliasGroup(listOf("ماشین حساب"), listOf("com.miui.calculator", "com.google.android.calculator", "com.android.calculator2", "calculator")),
        AliasGroup(listOf("ساعت", "الارم", "زنگ ساعت"), listOf("com.android.deskclock", "com.google.android.deskclock", "clock")),
        AliasGroup(listOf("تقویم"), listOf("com.google.android.calendar", "com.android.calendar", "calendar")),
        AliasGroup(listOf("گالری", "عکس ها", "تصاویر"), listOf("com.miui.gallery", "com.google.android.apps.photos", "com.sec.android.gallery3d", "gallery", "photos")),
        AliasGroup(listOf("فایل", "فایل ها", "مدیریت فایل"), listOf("com.mi.android.globalFileexplorer", "com.google.android.apps.nbu.files", "files", "file manager")),
        AliasGroup(listOf("موزیک", "موسیقی", "میوزیک"), listOf("com.miui.player", "music")),
        AliasGroup(listOf("یادداشت", "یادداشت ها"), listOf("com.miui.notes", "notes", "keep")),
        AliasGroup(listOf("هواشناسی", "آب و هوا"), listOf("com.miui.weather2", "weather")),
        AliasGroup(listOf("امنیت"), listOf("com.miui.securitycenter", "security")),
        AliasGroup(listOf("همراه من"), listOf("mci", "hamrah", "همراه من"))
    )

    // ---------------------------------------------------------------- لیست اپ‌ها

    /** باید روی ترد پس‌زمینه صدا زده شود (loadLabel سنگین است). */
    fun refresh(context: Context) {
        try {
            val pm = context.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(intent, 0).mapNotNull { info ->
                val label = info.loadLabel(pm).toString().trim()
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (label.isEmpty() || pkg == context.packageName) null
                else AppEntry(label, TextNorm.normalize(label), pkg)
            }
            apps = list
            Log.d(TAG, "Loaded ${list.size} launchable apps")
        } catch (e: Exception) {
            Log.e(TAG, "refresh failed", e)
        }
    }

    fun refreshAsync(context: Context) {
        val app = context.applicationContext
        Thread({ refresh(app) }, "sashi-app-scan").start()
    }

    // ---------------------------------------------------------------- باز کردن اپ

    /** برمی‌گرداند true اگر چیزی باز شد. */
    fun openApp(context: Context, spokenName: String): Boolean {
        val spoken = TextNorm.normalize(spokenName)
        if (spoken.isBlank()) return false

        if (openSystemTarget(context, spoken)) return true

        if (apps.isEmpty()) refresh(context) // اگر هنوز اسکن نشده، همین‌جا (روی ترد پس‌زمینه) اسکن کن
        val snapshot = apps

        // 1) alias ها
        val matchedGroups = aliasGroups
            .map { it to aliasScore(spoken, it) }
            .filter { it.second >= 0 }
            .sortedBy { it.second }
        for ((group, _) in matchedGroups) {
            val entry = resolveTargets(snapshot, group.targets) ?: continue
            if (launch(context, entry.pkg)) return true
        }

        // 2) نام نمایشی اپ‌های نصب‌شده
        val best = snapshot
            .map { it to labelScore(spoken, it.norm) }
            .filter { it.second >= 0 }
            .minByOrNull { it.second }
        if (best != null) return launch(context, best.first.pkg)
        return false
    }

    private fun aliasScore(spoken: String, g: AliasGroup): Int {
        var best = -1
        for (n in g.normNames) {
            val s = when {
                spoken == n -> 0
                n.length >= 3 && (" $spoken ").contains(" $n ") -> 1
                spoken.length >= 3 && (" $n ").contains(" $spoken ") -> 2
                else -> {
                    val d = TextNorm.levenshtein(spoken, n)
                    if (d <= TextNorm.allowedDistance(maxOf(spoken.length, n.length))) 3 + d else -1
                }
            }
            if (s >= 0 && (best < 0 || s < best)) best = s
        }
        return best
    }

    private fun resolveTargets(snapshot: List<AppEntry>, targets: List<String>): AppEntry? {
        for (t in targets) {
            if (t.contains('.')) {
                snapshot.firstOrNull { it.pkg == t }?.let { return it }
            } else {
                val key = TextNorm.normalize(t)
                snapshot.firstOrNull { it.norm == key }?.let { return it }
                snapshot.firstOrNull { it.norm.contains(key) || it.pkg.contains(key) }?.let { return it }
            }
        }
        return null
    }

    private fun labelScore(spoken: String, label: String): Int = when {
        spoken == label -> 0
        label.length >= 3 && (" $spoken ").contains(" $label ") -> 1
        spoken.length >= 3 && (" $label ").contains(" $spoken ") -> 2
        else -> {
            val d = TextNorm.levenshtein(spoken, label)
            if (d <= TextNorm.allowedDistance(maxOf(spoken.length, label.length))) 3 + d else -1
        }
    }

    private fun launch(context: Context, pkg: String): Boolean = try {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) false else {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        }
    } catch (e: Exception) {
        Log.e(TAG, "Cannot launch $pkg", e); false
    }

    /** تلفن، پیام‌ها، دوربین، تنظیمات، مخاطبین: با intent استاندارد (مستقل از نام اپ سازنده). */
    private fun openSystemTarget(context: Context, spoken: String): Boolean {
        val intent: Intent? = when (spoken) {
            "تلفن", "شماره گیر", "شماره گیری", "دایلر", "اپ تلفن" -> Intent(Intent.ACTION_DIAL)
            "پیام", "پیام ها", "پیامک", "پیامک ها", "اس ام اس", "مسیج", "مسیج ها" ->
                Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
            "دوربین" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            "تنظیمات" -> Intent(Settings.ACTION_SETTINGS)
            "مخاطبین", "مخاطب ها", "دفترچه تلفن" -> Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)
            else -> null
        }
        if (intent == null) return false
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.w(TAG, "System target failed for $spoken", e); false
        }
    }

    // ---------------------------------------------------------------- تماس

    enum class CallOutcome { CALLING, DIALER_ONLY, FAILED }

    fun callNumber(context: Context, number: String): CallOutcome {
        val clean = number.replace(Regex("[^0-9+*#]"), "")
        if (clean.isBlank()) return CallOutcome.FAILED
        val uri = Uri.parse("tel:" + Uri.encode(clean))
        val hasPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        try {
            if (hasPerm) {
                context.startActivity(Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return CallOutcome.CALLING
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "CALL_PHONE denied at runtime", e)
        } catch (e: Exception) {
            Log.w(TAG, "ACTION_CALL failed", e)
        }
        return try {
            context.startActivity(Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            CallOutcome.DIALER_ONLY
        } catch (e: Exception) {
            CallOutcome.FAILED
        }
    }

    // ---------------------------------------------------------------- پیامک

    fun openSms(context: Context, number: String? = null, body: String? = null): Boolean = try {
        val n = number.orEmpty().replace(Regex("[^0-9+]"), "")
        val intent: Intent = if (n.isEmpty() && body.isNullOrBlank()) {
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
        } else {
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).apply {
                if (!body.isNullOrBlank()) putExtra("sms_body", body)
            }
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: Exception) {
        Log.w(TAG, "openSms failed", e); false
    }

    // ---------------------------------------------------------------- مخاطبین

    sealed class ContactLookup {
        data class Found(val name: String, val number: String) : ContactLookup()
        object NotFound : ContactLookup()
        object NoPermission : ContactLookup()
    }

    fun findContact(context: Context, spokenName: String): ContactLookup {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) !=
            PackageManager.PERMISSION_GRANTED
        ) return ContactLookup.NoPermission

        val spoken = TextNorm.normalize(spokenName)
        if (spoken.isBlank()) return ContactLookup.NotFound

        var bestScore = Int.MAX_VALUE
        var bestName = ""
        var bestNumber = ""
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val number = c.getString(1) ?: continue
                    val n = TextNorm.normalize(name)
                    if (n.isEmpty()) continue
                    val score = labelScore(spoken, n)
                    if (score >= 0 && score < bestScore) {
                        bestScore = score; bestName = name; bestNumber = number
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "contact query failed", e)
        }
        return if (bestScore == Int.MAX_VALUE) ContactLookup.NotFound
        else ContactLookup.Found(bestName, bestNumber)
    }
}
