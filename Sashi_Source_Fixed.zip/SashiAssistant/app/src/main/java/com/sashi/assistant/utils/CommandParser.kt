package com.sashi.assistant.utils

import android.content.Context

sealed class CommandResult {
    data class OpenApp(val appName: String) : CommandResult()
    /** target: شماره (isNumber=true) یا اسم مخاطب */
    data class Call(val target: String, val isNumber: Boolean) : CommandResult()
    data class OpenSms(val target: String? = null, val isNumber: Boolean = false, val body: String? = null) : CommandResult()
    data class Unknown(val original: String) : CommandResult()
    object LockScreen : CommandResult()
    object None : CommandResult()
}

/** postAction: بعد از تمام شدن پاسخ صوتی اجرا می‌شود (مثلاً قفل کردن صفحه). */
data class ExecResult(val message: String, val success: Boolean, val postAction: (() -> Unit)? = null)

object CommandParser {

    private val callKeywords = listOf(
        "زنگ بزن", "زنگ بزنید", "تماس بگیر", "تماس بگیرید", "شماره بگیر", "شماره گیری کن",
        "تلفن بزن", "تلفن کن", "کال بگیر", "تماس با"
    )
    private val smsKeywords = listOf(
        "پیام بده", "پیام بفرست", "پیام بزن", "پیامک بده", "پیامک بفرست", "پیامک بزن",
        "اس ام اس بده", "اس ام اس بفرست", "مسیج بده", "مسیج بفرست"
    )
    private val openKeywords = listOf(
        "باز کن", "بازکن", "باز کنید", "باز بکن", "اجرا کن", "راه بنداز", "بالا بیار", "برو به", "برو تو", "بیار"
    )
    private val fillers = setOf(
        "را", "رو", "به", "با", "برای", "اپ", "اپلیکیشن", "برنامه", "نرم", "افزار", "لطفا", "لطفاً",
        "شماره", "یه", "ی", "من", "ساشی", "سلام"
    )

    private fun removeKeyword(norm: String, kw: String): String? {
        val padded = " $norm "
        val key = " ${TextNorm.normalize(kw)} "
        val idx = padded.indexOf(key)
        if (idx < 0) return null
        val before = padded.substring(0, idx)
        val after = padded.substring(idx + key.length - 1)
        return (before + " " + after).trim()
    }

    private fun stripFillers(text: String): String =
        text.split(' ').filter { it.isNotBlank() && it !in fillers }.joinToString(" ").trim()

    fun parse(text: String): CommandResult {
        val norm = TextNorm.normalize(text)
        if (norm.isBlank()) return CommandResult.None

        // --- قفل / خاموش کردن صفحه
        val tokens = norm.split(' ').toSet()
        val screenWords = setOf("گوشی", "صفحه", "موبایل", "نمایشگر", "اسکرین", "تلفن")
        if ("قفل" in tokens || ("خاموش" in tokens && tokens.any { it in screenWords })) {
            return CommandResult.LockScreen
        }

        // --- تماس
        for (kw in callKeywords) {
            val rest = removeKeyword(norm, kw) ?: continue
            val target = stripFillers(rest)
            if (target.isBlank()) return CommandResult.Unknown(norm)
            val digits = TextNorm.spokenDigits(target)
            return if (digits != null) CommandResult.Call(digits, true) else CommandResult.Call(target, false)
        }

        // --- پیامک (ارسال به شخص)
        for (kw in smsKeywords) {
            val rest = removeKeyword(norm, kw) ?: continue
            // «... که <متن پیام>»
            val padded = " $rest "
            val kIdx = padded.indexOf(" که ")
            val targetPart = if (kIdx >= 0) padded.substring(0, kIdx) else rest
            val body = if (kIdx >= 0) padded.substring(kIdx + 3).trim().ifBlank { null } else null
            val target = stripFillers(targetPart)
            if (target.isBlank()) return CommandResult.OpenSms(null, false, body)
            val digits = TextNorm.spokenDigits(target)
            return if (digits != null) CommandResult.OpenSms(digits, true, body)
            else CommandResult.OpenSms(target, false, body)
        }

        // --- باز کردن اپ
        for (kw in openKeywords) {
            val rest = removeKeyword(norm, kw) ?: continue
            val name = stripFillers(rest)
            if (name.isNotBlank()) return CommandResult.OpenApp(name)
        }

        // فقط اسم اپ گفته شده
        return CommandResult.Unknown(stripFillers(norm).ifBlank { norm })
    }

    /** روی ترد پس‌زمینه صدا زده شود (جستجوی مخاطب و اسکن اپ‌ها سنگین‌اند). */
    fun execute(context: Context, result: CommandResult): ExecResult = when (result) {
        is CommandResult.OpenApp ->
            if (AppLauncher.openApp(context, result.appName)) ExecResult("چشم، ${result.appName} باز شد", true)
            else ExecResult("برنامه ${result.appName} رو پیدا نکردم", false)

        is CommandResult.Call -> executeCall(context, result)

        is CommandResult.OpenSms -> executeSms(context, result)

        is CommandResult.Unknown ->
            if (result.original.isNotBlank() && AppLauncher.openApp(context, result.original))
                ExecResult("چشم، باز شد", true)
            else ExecResult("متوجه دستورت نشدم", false)

        CommandResult.LockScreen ->
            if (ScreenLocker.isActive(context))
                ExecResult("چشم، صفحه رو قفل می‌کنم", true) { ScreenLocker.lockNow(context) }
            else ExecResult("اول داخل برنامه ساشی، دسترسی قفل صفحه رو فعال کن", false)

        CommandResult.None -> ExecResult("چیزی نشنیدم", false)
    }

    private fun executeCall(context: Context, c: CommandResult.Call): ExecResult {
        var number = c.target
        var display = c.target
        if (!c.isNumber) {
            when (val r = AppLauncher.findContact(context, c.target)) {
                is AppLauncher.ContactLookup.Found -> { number = r.number; display = r.name }
                AppLauncher.ContactLookup.NotFound ->
                    return ExecResult("مخاطبی به اسم ${c.target} پیدا نکردم", false)
                AppLauncher.ContactLookup.NoPermission ->
                    return ExecResult("اجازه دسترسی به مخاطبین رو بده تا بتونم زنگ بزنم", false)
            }
        }
        return when (AppLauncher.callNumber(context, number)) {
            AppLauncher.CallOutcome.CALLING ->
                ExecResult(if (c.isNumber) "چشم، دارم تماس می‌گیرم" else "چشم، دارم به $display زنگ می‌زنم", true)
            AppLauncher.CallOutcome.DIALER_ONLY ->
                ExecResult("شماره‌گیر رو باز کردم؛ برای تماس مستقیم، اجازه تماس رو در تنظیمات بده", true)
            AppLauncher.CallOutcome.FAILED ->
                ExecResult("نتونستم تماس بگیرم", false)
        }
    }

    private fun executeSms(context: Context, s: CommandResult.OpenSms): ExecResult {
        var number: String? = null
        var display: String? = null
        val target = s.target
        if (target != null) {
            if (s.isNumber) { number = target; display = target }
            else when (val r = AppLauncher.findContact(context, target)) {
                is AppLauncher.ContactLookup.Found -> { number = r.number; display = r.name }
                AppLauncher.ContactLookup.NotFound ->
                    return ExecResult("مخاطبی به اسم $target پیدا نکردم", false)
                AppLauncher.ContactLookup.NoPermission ->
                    return ExecResult("اجازه دسترسی به مخاطبین رو بده", false)
            }
        }
        return if (AppLauncher.openSms(context, number, s.body)) {
            ExecResult(if (display != null) "چشم، پیام برای $display آماده‌ست" else "چشم، پیام‌ها باز شد", true)
        } else ExecResult("نتونستم پیام‌ها رو باز کنم", false)
    }
}
