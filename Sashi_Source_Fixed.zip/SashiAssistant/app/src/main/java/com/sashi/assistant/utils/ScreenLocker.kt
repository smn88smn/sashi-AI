package com.sashi.assistant.utils

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import com.sashi.assistant.service.SashiAdminReceiver

/** قفل کردن صفحه با Device Admin (policy: force-lock). روی همه نسخه‌ها از اندروید ۸ به بعد کار می‌کند. */
object ScreenLocker {

    private fun component(context: Context) = ComponentName(context, SashiAdminReceiver::class.java)

    private fun dpm(context: Context) =
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    fun isActive(context: Context): Boolean =
        dpm(context).isAdminActive(component(context))

    fun lockNow(context: Context): Boolean = try {
        if (isActive(context)) { dpm(context).lockNow(); true } else false
    } catch (e: Exception) {
        Log.e("Sashi", "lockNow failed", e); false
    }

    fun requestIntent(context: Context): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component(context))
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "برای اینکه ساشی بتواند با دستور صوتی صفحه را قفل کند."
            )
        }

    fun deactivate(context: Context) {
        try { dpm(context).removeActiveAdmin(component(context)) } catch (_: Exception) {}
    }
}
