package com.sashi.assistant.utils

import java.util.Locale

/** نرمال‌سازی متن فارسی/عربی + ابزارهای تطبیق تقریبی */
object TextNorm {

    private val diacritics = Regex("[\\u064B-\\u065F\\u0670\\u0640]")
    private val notWord = Regex("[^\\p{L}\\p{N}\\s+]")
    private val spaces = Regex("\\s+")

    fun normalize(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input.lowercase(Locale.ROOT)) {
            when (ch) {
                'ي', 'ى' -> sb.append('ی')
                'ك' -> sb.append('ک')
                'آ', 'أ', 'إ' -> sb.append('ا')
                'ة' -> sb.append('ه')
                'ؤ' -> sb.append('و')
                '\u200c', '\u200f', '\u200e', '_', '-' -> sb.append(' ')
                in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                else -> sb.append(ch)
            }
        }
        return sb.toString()
            .let { diacritics.replace(it, "") }
            .let { notWord.replace(it, " ") }
            .let { spaces.replace(it, " ") }
            .trim()
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    /** حداکثر فاصله مجاز برای تطبیق تقریبی بر اساس طول کلمه */
    fun allowedDistance(len: Int): Int = when {
        len <= 3 -> 0
        len <= 6 -> 1
        else -> 2
    }

    private val digitWords = mapOf(
        "صفر" to '0', "یک" to '1', "یه" to '1', "دو" to '2', "سه" to '3',
        "چهار" to '4', "چار" to '4', "پنج" to '5', "شش" to '6', "شیش" to '6',
        "هفت" to '7', "هشت" to '8', "نه" to '9'
    )

    /**
     * اگر متن (نرمال‌شده) فقط از ارقام (به صورت عدد یا کلمه) تشکیل شده باشد، رشته‌ی ارقام را برمی‌گرداند.
     * Vosk معمولاً اعداد را به صورت کلمه می‌نویسد: «صفر نه یک دو ...»
     */
    fun spokenDigits(norm: String): String? {
        val tokens = norm.split(' ').filter { it.isNotBlank() && it != "و" }
        if (tokens.isEmpty()) return null
        val sb = StringBuilder()
        for (t in tokens) {
            val w = digitWords[t]
            when {
                w != null -> sb.append(w)
                t.all { it.isDigit() || it == '+' } -> sb.append(t)
                else -> return null
            }
        }
        return sb.toString().takeIf { it.count { c -> c.isDigit() } >= 3 }
    }
}
