package com.sashi.assistant.voice

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

/**
 * پاسخ صوتی فارسی. اگر موتور TTS فارسی نداشته باشد، callback بعد از یک مکث کوتاه صدا زده می‌شود
 * تا دستیار گیر نکند و بسته شود.
 */
object TtsHelper {

    enum class Status { CHECKING, PERSIAN_OK, PERSIAN_MISSING, ENGINE_FAILED }

    private const val TAG = "Sashi"

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private var persianOk = false

    private val _status = MutableStateFlow(Status.CHECKING)
    val status: StateFlow<Status> = _status

    private var token = 0
    private var currentDone: (() -> Unit)? = null
    private var pendingText: String? = null

    fun init(context: Context) {
        if (tts != null) return
        val app = context.applicationContext
        var created: TextToSpeech? = null
        created = TextToSpeech(app) { st ->
            main.post {
                val engine = created
                if (st != TextToSpeech.SUCCESS || engine == null) {
                    Log.e(TAG, "TTS init failed")
                    _status.value = Status.ENGINE_FAILED
                    ready = true
                    flushPending()
                    return@post
                }
                var r = engine.setLanguage(Locale("fa", "IR"))
                if (r < TextToSpeech.LANG_AVAILABLE) r = engine.setLanguage(Locale("fa"))
                persianOk = r >= TextToSpeech.LANG_AVAILABLE
                _status.value = if (persianOk) Status.PERSIAN_OK else Status.PERSIAN_MISSING
                engine.setSpeechRate(0.98f)
                engine.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { finishUtterance(utteranceId) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { finishUtterance(utteranceId) }
                })
                ready = true
                flushPending()
            }
        }
        tts = created
    }

    private fun finishUtterance(id: String?) {
        val t = id?.removePrefix("sashi_")?.toIntOrNull() ?: return
        main.post { complete(t) }
    }

    private fun flushPending() {
        val text = pendingText ?: return
        pendingText = null
        doSpeak(text, token)
    }

    /** onDone دقیقاً یک بار روی ترد اصلی صدا زده می‌شود (حتی اگر TTS خراب باشد). */
    fun speak(text: String, onDone: () -> Unit) {
        main.post {
            val my = ++token
            currentDone = onDone
            pendingText = null
            if (!ready) {
                pendingText = text
                main.postDelayed({ if (token == my && !ready) complete(my) }, 3000)
                return@post
            }
            doSpeak(text, my)
        }
    }

    private fun doSpeak(text: String, t: Int) {
        if (!persianOk || tts == null) {
            main.postDelayed({ complete(t) }, 1500)
            return
        }
        val r = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sashi_$t")
        if (r != TextToSpeech.SUCCESS) {
            main.postDelayed({ complete(t) }, 500)
            return
        }
        main.postDelayed({ complete(t) }, 12_000) // watchdog
    }

    private fun complete(t: Int) {
        if (t != token) return
        val cb = currentDone
        currentDone = null
        token++
        cb?.invoke()
    }

    fun stop() {
        main.post {
            token++
            currentDone = null
            pendingText = null
            try { tts?.stop() } catch (_: Exception) {}
        }
    }
}
