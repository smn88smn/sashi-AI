package com.sashi.assistant.voice

import android.content.Context
import android.content.res.AssetManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import kotlin.math.sqrt

/**
 * تشخیص گفتار آفلاین فارسی با Vosk.
 * مدل یک بار (singleton) بارگذاری می‌شود و بین دفعات باز شدن دستیار در حافظه می‌ماند.
 * مدل از assets/model-fa خوانده و یک بار در filesDir کپی می‌شود.
 */
object VoskHelper {

    private const val TAG = "Sashi"
    private const val ASSET_DIR = "model-fa"
    private const val SAMPLE_RATE = 16000
    private const val NO_SPEECH_TIMEOUT_MS = 8_000L
    private const val MAX_DURATION_MS = 15_000L

    sealed class ModelState {
        object Idle : ModelState()
        object Loading : ModelState()
        object Ready : ModelState()
        data class Failed(val reason: String) : ModelState()
    }

    private val _modelState = MutableStateFlow<ModelState>(ModelState.Idle)
    val modelState: StateFlow<ModelState> = _modelState

    @Volatile private var model: Model? = null

    interface Listener {
        fun onLevel(level: Float)
        fun onPartial(text: String)
        fun onResult(text: String)
        fun onNoSpeech()
        fun onError(message: String)
    }

    fun hasModelAsset(context: Context): Boolean = try {
        val root = context.applicationContext.assets.list(ASSET_DIR)
        root != null && root.isNotEmpty()
    } catch (e: IOException) {
        false
    }

    @Synchronized
    fun preload(context: Context) {
        val s = _modelState.value
        if (s is ModelState.Ready || s is ModelState.Loading) return
        _modelState.value = ModelState.Loading
        val app = context.applicationContext
        Thread({
            try {
                val dir = prepareModelDir(app)
                LibVosk.setLogLevel(LogLevel.WARNINGS)
                model = Model(dir.absolutePath)
                _modelState.value = ModelState.Ready
                Log.d(TAG, "Vosk model loaded from ${dir.absolutePath}")
            } catch (t: Throwable) {
                Log.e(TAG, "Vosk model load failed", t)
                _modelState.value = ModelState.Failed(t.message ?: t.javaClass.simpleName)
            }
        }, "vosk-model-loader").start()
    }

    // ------------------------------------------------------------ کپی مدل از assets

    private fun prepareModelDir(ctx: Context): File {
        val assets = ctx.assets
        val rootList = assets.list(ASSET_DIR)
        if (rootList.isNullOrEmpty()) {
            throw IOException("پوشه assets/$ASSET_DIR پیدا نشد یا خالی است")
        }
        val target = File(ctx.filesDir, "vosk/$ASSET_DIR")
        val stamp = try {
            @Suppress("DEPRECATION")
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime
        } catch (e: Exception) { 0L }
        val marker = File(target, ".copied_$stamp")

        if (!marker.exists()) {
            target.deleteRecursively()
            target.mkdirs()
            copyAssets(assets, ASSET_DIR, target)
            marker.writeText("ok")
        }
        return resolveRoot(target)
    }

    private fun copyAssets(am: AssetManager, src: String, dst: File) {
        val children = am.list(src)
        if (children.isNullOrEmpty()) {
            try {
                dst.parentFile?.mkdirs()
                am.open(src).use { input -> dst.outputStream().use { out -> input.copyTo(out) } }
            } catch (e: FileNotFoundException) {
                dst.mkdirs()
            }
        } else {
            dst.mkdirs()
            for (c in children) copyAssets(am, "$src/$c", File(dst, c))
        }
    }

    private fun resolveRoot(dir: File): File {
        if (File(dir, "am").isDirectory) return dir
        val nested = dir.listFiles()?.firstOrNull { it.isDirectory && File(it, "am").isDirectory }
        return nested ?: throw IOException("ساختار مدل نامعتبر است (پوشه am پیدا نشد)")
    }

    // ------------------------------------------------------------ گوش دادن

    class ListeningSession internal constructor(private val listener: Listener) {
        @Volatile private var running = true
        private val main = Handler(Looper.getMainLooper())

        fun cancel() { running = false }

        private fun post(block: () -> Unit) { main.post { block() } }

        private fun parse(json: String?, key: String): String =
            try { JSONObject(json ?: "{}").optString(key, "").trim() } catch (e: Exception) { "" }

        internal fun run(model: Model) {
            var record: AudioRecord? = null
            var recognizer: Recognizer? = null
            try {
                val minBuf = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val bufSize = maxOf(minBuf, SAMPLE_RATE * 2)
                record = try {
                    AudioRecord(
                        MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize
                    )
                } catch (e: SecurityException) {
                    post { if (running) listener.onError("مجوز میکروفون داده نشده") }
                    return
                }
                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    post { if (running) listener.onError("میکروفون در دسترس نیست") }
                    return
                }

                recognizer = Recognizer(model, SAMPLE_RATE.toFloat())
                record.startRecording()

                val buf = ShortArray(1600) // ۱۰۰ میلی‌ثانیه
                val start = SystemClock.elapsedRealtime()
                var heardSpeech = false
                var lastPartial = ""

                while (running) {
                    val n = record.read(buf, 0, buf.size)
                    if (n < 0) {
                        post { if (running) listener.onError("خطا در خواندن میکروفون") }
                        return
                    }
                    if (n == 0) continue

                    var sum = 0.0
                    for (i in 0 until n) sum += buf[i].toDouble() * buf[i].toDouble()
                    val rms = sqrt(sum / n).toFloat()
                    val level = (rms / 3000f).coerceIn(0f, 1f)
                    post { if (running) listener.onLevel(level) }

                    if (recognizer.acceptWaveForm(buf, n)) {
                        val text = parse(recognizer.result, "text")
                        if (text.isNotBlank()) {
                            running = false
                            post { listener.onResult(text) }
                            return
                        }
                    } else {
                        val p = parse(recognizer.partialResult, "partial")
                        if (p.isNotBlank()) {
                            heardSpeech = true
                            if (p != lastPartial) {
                                lastPartial = p
                                post { if (running) listener.onPartial(p) }
                            }
                        }
                    }

                    val elapsed = SystemClock.elapsedRealtime() - start
                    if (!heardSpeech && elapsed > NO_SPEECH_TIMEOUT_MS) {
                        running = false
                        post { listener.onNoSpeech() }
                        return
                    }
                    if (elapsed > MAX_DURATION_MS) {
                        val text = parse(recognizer.finalResult, "text")
                        running = false
                        post { if (text.isNotBlank()) listener.onResult(text) else listener.onNoSpeech() }
                        return
                    }
                }
            } catch (t: Throwable) {
                Log.e(TAG, "listening failed", t)
                post { if (running) listener.onError(t.message ?: "خطای تشخیص گفتار") }
            } finally {
                try { record?.stop() } catch (_: Exception) {}
                try { record?.release() } catch (_: Exception) {}
                try { recognizer?.close() } catch (_: Exception) {}
            }
        }
    }

    /** باید بعد از Ready بودن مدل صدا زده شود. null یعنی مدل آماده نیست. */
    fun startListening(listener: Listener): ListeningSession? {
        val m = model ?: return null
        val session = ListeningSession(listener)
        Thread({ session.run(m) }, "vosk-listen").apply { isDaemon = true }.start()
        return session
    }
}
