# Sashi build status

## Source project inspection
- Kotlin source files, Android manifest, Compose UI, Vosk integration, TTS helper, app launcher, and VoiceInteraction service classes are present.
- The project is configured for Android Gradle Plugin 8.3.2, Kotlin 1.9.22, compile/target SDK 34, and min SDK 26.
- Persian model is not bundled in this source archive; `bash download-model.sh` downloads the official `vosk-model-small-fa-0.42` archive and places it under `app/src/main/assets/model-fa/`.
- `download-model.sh` passes Bash syntax validation.
- Android XML resources and manifest parse successfully.

## Not verified / not completed
- No APK has been built in this workspace.
- This workspace has no Android SDK, no Gradle installation or wrapper JAR, and outbound DNS/network access is unavailable. Therefore dependencies and the Persian model cannot be downloaded here.
- Kotlin compilation, Gradle packaging, and device installation have not been run.
- No physical Xiaomi/HyperOS device test has been run; default-assistant behavior must be verified on the target OS version.
- Alarm scheduling and contact management are not implemented in this source snapshot.

## Build requirements
- JDK 17 (JDK 21 may also work with the selected Gradle/AGP versions, but JDK 17 is the documented baseline)
- Gradle 8.6
- Android SDK Platform 34 and Build Tools 34.0.0
- Network access for Maven dependencies and the official Vosk model archive

## Build commands
From the project root:

```bash
bash download-model.sh
gradle --no-daemon :app:assembleDebug
```

Expected APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```
