package com.sashi.assistant

import android.app.Application
import com.sashi.assistant.utils.AppLauncher
import com.sashi.assistant.voice.TtsHelper

class SashiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppLauncher.init(this)
        TtsHelper.init(this)
    }
}
