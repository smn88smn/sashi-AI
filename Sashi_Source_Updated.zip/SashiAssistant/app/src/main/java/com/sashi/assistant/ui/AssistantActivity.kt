package com.sashi.assistant.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.sashi.assistant.ui.theme.SashiTheme
import com.sashi.assistant.utils.CommandParser
import com.sashi.assistant.utils.CommandResult
import com.sashi.assistant.voice.TtsHelper
import com.sashi.assistant.voice.VoskHelper

class AssistantActivity : ComponentActivity() {
    private lateinit var vosk: VoskHelper
    private val main = Handler(Looper.getMainLooper())
    private var uiStatus by mutableStateOf("در حال آماده‌سازی…")
    private var uiText by mutableStateOf("")
    private var uiMode by mutableStateOf(Mode.LOADING)
    private var handled = false

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) loadModel() else { uiMode = Mode.ERROR; uiStatus = "برای کار کردن ساشی، مجوز میکروفون لازمه" }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        vosk = VoskHelper(this)
        TtsHelper.init(this)
        setContent { SashiTheme { AssistantScreen(uiStatus, uiText, uiMode, onClose = { finish() }, onRetry = { handled = false; beginListening() }) } }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) loadModel()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun loadModel() {
        uiMode = Mode.LOADING; uiStatus = "مدل فارسی در حال بارگذاری است…"
        vosk.initModel { ok, error -> main.post {
            if (ok) beginListening() else { uiMode = Mode.ERROR; uiStatus = error ?: "مدل گفتار بارگذاری نشد" }
        } }
    }

    private fun beginListening() {
        if (isFinishing || handled) return
        uiMode = Mode.LISTENING; uiStatus = "دارم گوش می‌دم…"; uiText = ""
        vosk.startListening(object : VoskHelper.Listener {
            override fun onPartial(text: String) { main.post { if (!handled) uiText = text } }
            override fun onFinal(text: String) { main.post { handleCommand(text) } }
            override fun onError(message: String) { main.post { if (!handled) { uiMode = Mode.ERROR; uiStatus = message } } }
            override fun onTimeout() { main.post { if (!handled) { uiStatus = "صدایی نشنیدم؛ دوباره امتحان کن"; uiMode = Mode.ERROR } } }
        })
    }

    private fun handleCommand(text: String) {
        if (handled || text.isBlank()) return
        handled = true
        uiText = text; uiMode = Mode.PROCESSING; uiStatus = "در حال انجام دستور…"
        vosk.stopListening()
        Thread {
            val result = CommandParser.parse(text)
            val reply = CommandParser.execute(this, result)
            main.post {
                uiStatus = reply.ifBlank { "دستور دریافت نشد" }
                uiMode = if (reply.startsWith("چشم") || reply.contains("باز شد") || reply.contains("شماره‌گیر")) Mode.SUCCESS else Mode.ERROR
                TtsHelper.speak(reply)
                main.postDelayed({ if (!isFinishing) finish() }, 1900)
            }
        }.start()
    }

    override fun onDestroy() {
        vosk.release()
        super.onDestroy()
    }
}

enum class Mode { LOADING, LISTENING, PROCESSING, SUCCESS, ERROR }

@Composable
private fun AssistantScreen(status: String, recognized: String, mode: Mode, onClose: () -> Unit, onRetry: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(0.94f, 1.08f, infiniteRepeatable(tween(850, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse-scale")
    val accent = when (mode) { Mode.SUCCESS -> Color(0xFF22C55E); Mode.ERROR -> Color(0xFFFF647C); Mode.PROCESSING -> Color(0xFFA855F7); else -> Color(0xFF00D4FF) }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.48f)), contentAlignment = Alignment.BottomCenter) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 18.dp),
            shape = RoundedCornerShape(30.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xF2141B2A)),
            elevation = CardDefaults.cardElevation(18.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("SASHI", color = Color(0xFF00D4FF), fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Spacer(Modifier.height(20.dp))
                Box(Modifier.size(104.dp).scale(if (mode == Mode.LISTENING) pulse else 1f).clip(CircleShape).background(Brush.radialGradient(listOf(accent.copy(alpha = .34f), Color.Transparent))), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(72.dp).clip(CircleShape).background(accent), contentAlignment = Alignment.Center) {
                        Text(when (mode) { Mode.SUCCESS -> "✓"; Mode.ERROR -> "!"; Mode.PROCESSING -> "•••"; Mode.LOADING -> "…"; Mode.LISTENING -> "🎙" }, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text(status, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                if (recognized.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text("«$recognized»", color = Color(0xFFB7C4D8), fontSize = 14.sp, textAlign = TextAlign.Center)
                }
                if (mode == Mode.ERROR) {
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = onRetry) { Text("تلاش دوباره") }
                        TextButton(onClick = onClose) { Text("بستن") }
                    }
                }
            }
        }
    }
}
