package com.sashi.assistant.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import java.text.Normalizer
import java.util.Locale

object AppLauncher {
    private val appMap = mutableMapOf<String, String>()
    private fun normalize(s: String) = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFKC)
        .replace("ي", "ی").replace("ك", "ک").replace("‌", " ").replace(Regex("""\s+"""), " ").trim()

    fun init(context: Context) {
        appMap.clear()
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, 0).forEach { info ->
            val name = normalize(info.loadLabel(pm).toString())
            val pkg = info.activityInfo.packageName
            if (name.isNotBlank()) appMap[name] = pkg
            val aliases = mapOf(
                "instagram" to listOf("instagram", "اینستاگرام", "اینستا"),
                "telegram" to listOf("telegram", "تلگرام"),
                "whatsapp" to listOf("whatsapp", "واتساپ", "واتس اپ"),
                "youtube" to listOf("youtube", "یوتیوب"),
                "chrome" to listOf("chrome", "کروم"),
                "settings" to listOf("settings", "تنظیمات"),
                "camera" to listOf("camera", "دوربین"),
                "phone" to listOf("phone", "dialer", "تلفن", "تماس"),
                "messages" to listOf("messages", "messaging", "sms", "پیام", "پیامک", "پیام ها", "پیام‌ها")
            )
            aliases.values.flatten().forEach { alias ->
                if (name.contains(normalize(alias)) || normalize(alias).contains(name)) appMap[normalize(alias)] = pkg
            }
        }
    }

    fun openApp(context: Context, spokenName: String): Boolean {
        if (appMap.isEmpty()) init(context)
        val key = normalize(spokenName)
        val pkg = appMap[key] ?: appMap.entries.firstOrNull { (label, _) -> label.contains(key) || key.contains(label) }?.value
            ?: return false
        return try {
            val launch = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launch)
            true
        } catch (e: Exception) { Log.e("Sashi", "Cannot open $pkg", e); false }
    }

    // تماس فقط شماره‌گیر را باز می‌کند؛ تماس بدون تأیید کاربر برقرار نمی‌شود.
    fun callNumber(context: Context, number: String): Boolean {
        val clean = number.replace(Regex("[^0-9+*#]"), "")
        if (clean.isBlank()) return false
        return try {
            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$clean")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (_: Exception) { false }
    }

    fun openSms(context: Context, number: String? = null, body: String? = null): Boolean = try {
        val uri = Uri.parse("smsto:${number.orEmpty().replace(Regex("[^0-9+]"), "")}")
        val intent = Intent(Intent.ACTION_SENDTO, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!body.isNullOrBlank()) intent.putExtra("sms_body", body)
        context.startActivity(intent)
        true
    } catch (_: Exception) { false }
}
