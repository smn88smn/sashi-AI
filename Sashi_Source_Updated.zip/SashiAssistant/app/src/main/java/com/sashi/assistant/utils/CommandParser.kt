package com.sashi.assistant.utils

import android.content.Context

sealed class CommandResult {
    data class OpenApp(val appName: String) : CommandResult()
    data class Call(val number: String) : CommandResult()
    data class OpenSms(val number: String? = null, val body: String? = null) : CommandResult()
    data class Unknown(val original: String) : CommandResult()
    object None : CommandResult()
}

object CommandParser {
    private fun clean(input: String) = input.lowercase()
        .replace("ي", "ی").replace("ك", "ک").replace("‌", " ")
        .replace(Regex("""\s+"""), " ").trim()

    fun parse(text: String): CommandResult {
        val s = clean(text)
        if (s.isBlank()) return CommandResult.None
        val call = Regex("""(?:به\s*)?([+0-9۰-۹][+0-9۰-۹\s-]{5,})\s*(?:زنگ بزن|تماس بگیر)?|(?:زنگ بزن|تماس بگیر)\s*(?:به\s*)?([+0-9۰-۹][+0-9۰-۹\s-]{5,})""").find(s)
        if (call != null) {
            val raw = call.groupValues.drop(1).firstOrNull { it.isNotBlank() } ?: ""
            val digits = raw.map { if (it in '۰'..'۹') ('0'.code + it.code - '۰'.code).toChar() else it }.joinToString("").replace(Regex("[^0-9+]"), "")
            if (digits.length >= 6) return CommandResult.Call(digits)
        }
        if (listOf("پیام ها", "پیام‌ها", "پیامک ها", "پیامک‌ها", "پیام ها را باز کن").any { s.contains(it) }) return CommandResult.OpenSms()
        val sms = Regex("""(?:پیام بده|پیامک بده|پیام بفرست)\s*(?:به\s*)?([+0-9۰-۹]+)""").find(s)
        if (sms != null) return CommandResult.OpenSms(sms.groupValues[1])
        val openPatterns = listOf(
            Regex("""(?:باز کن|بازکن|باز بکن|بیار|برو به)\s*(.+)$"""),
            Regex("""(.+?)\s*(?:را|رو)\s*باز کن$""")
        )
        for (pattern in openPatterns) {
            val m = pattern.find(s) ?: continue
            val name = m.groupValues[1].replace(Regex("""\s*(را|رو)$"""), "").trim()
            if (name.isNotBlank()) return CommandResult.OpenApp(name)
        }
        return CommandResult.Unknown(s)
    }

    fun execute(context: Context, result: CommandResult): String = when (result) {
        is CommandResult.OpenApp -> if (AppLauncher.openApp(context, result.appName)) "چشم، ${result.appName} باز شد" else "برنامه ${result.appName} پیدا نشد"
        is CommandResult.Call -> if (AppLauncher.callNumber(context, result.number)) "شماره‌گیر باز شد؛ قبل از تماس شماره را بررسی کن" else "نتونستم شماره‌گیر رو باز کنم"
        is CommandResult.OpenSms -> if (AppLauncher.openSms(context, result.number, result.body)) "پیام‌ها باز شد" else "نتونستم پیام‌ها رو باز کنم"
        is CommandResult.Unknown -> if (AppLauncher.openApp(context, result.original)) "برنامه باز شد" else "متوجه دستورت نشدم"
        CommandResult.None -> ""
    }
}
