package com.sashi.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

object TtsHelper {
    private var engine: TextToSpeech? = null
    @Volatile private var ready = false

    fun init(context: Context) {
        if (engine != null) return
        engine = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val t = engine ?: return@TextToSpeech
                val fa = t.setLanguage(Locale("fa", "IR"))
                if (fa == TextToSpeech.LANG_MISSING_DATA || fa == TextToSpeech.LANG_NOT_SUPPORTED) {
                    t.setLanguage(Locale("fa"))
                }
                t.setSpeechRate(0.98f)
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) = Unit
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { Log.w("Sashi", "TTS error") }
                })
                ready = true
            } else Log.e("Sashi", "TTS initialization failed")
        }
    }

    fun speak(text: String) {
        if (ready && text.isNotBlank()) engine?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sashi-${System.currentTimeMillis()}")
    }

    fun stop() { engine?.stop() }
    fun shutdown() { engine?.shutdown(); engine = null; ready = false }
}
