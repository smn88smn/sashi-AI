package com.sashi.assistant.voice

import android.content.Context
import android.util.Log
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File

class VoskHelper(private val context: Context) {
    private var model: Model? = null
    private var speechService: SpeechService? = null
    @Volatile private var listening = false

    interface Listener {
        fun onPartial(text: String)
        fun onFinal(text: String)
        fun onError(message: String)
        fun onTimeout()
    }

    fun initModel(onReady: (Boolean, String?) -> Unit) {
        Thread {
            try {
                val modelDir = File(context.filesDir, "model-fa")
                if (!File(modelDir, "am").exists() || !File(modelDir, "conf").exists()) {
                    copyAssetFolder("model-fa", modelDir)
                }
                require(File(modelDir, "am").exists()) { "مدل فارسی داخل برنامه موجود نیست" }
                model = Model(modelDir.absolutePath)
                onReady(true, null)
            } catch (e: Exception) {
                Log.e("Sashi", "Vosk initialization failed", e)
                onReady(false, e.message ?: "خطا در بارگذاری مدل")
            }
        }.start()
    }

    private fun copyAssetFolder(assetPath: String, destination: File) {
        val children = context.assets.list(assetPath) ?: emptyArray()
        if (children.isEmpty()) {
            destination.parentFile?.mkdirs()
            context.assets.open(assetPath).use { input -> destination.outputStream().use(input::copyTo) }
            return
        }
        destination.mkdirs()
        for (child in children) {
            copyAssetFolder("$assetPath/$child", File(destination, child))
        }
    }

    fun startListening(listener: Listener) {
        val loaded = model
        if (loaded == null) { listener.onError("مدل گفتار هنوز آماده نیست"); return }
        if (listening) return
        try {
            val recognizer = Recognizer(loaded, 16000.0f)
            speechService = SpeechService(recognizer, 16000.0f)
            listening = true
            speechService?.startListening(object : RecognitionListener {
                override fun onPartialResult(hypothesis: String?) {
                    parse(hypothesis)?.takeIf { it.isNotBlank() }?.let(listener::onPartial)
                }
                override fun onResult(hypothesis: String?) {
                    parse(hypothesis)?.takeIf { it.isNotBlank() }?.let(listener::onFinal)
                }
                override fun onFinalResult(hypothesis: String?) {
                    parse(hypothesis)?.takeIf { it.isNotBlank() }?.let(listener::onFinal)
                    stopListening()
                }
                override fun onError(e: Exception?) {
                    listening = false
                    listener.onError(e?.localizedMessage ?: "خطای تشخیص صدا")
                }
                override fun onTimeout() {
                    listening = false
                    listener.onTimeout()
                }
            })
        } catch (e: Exception) {
            listening = false
            listener.onError(e.localizedMessage ?: "شروع میکروفون ناموفق بود")
        }
    }

    private fun parse(json: String?): String? {
        if (json.isNullOrBlank()) return null
        return Regex(""""(?:text|partial)"\s*:\s*"([^\"]*)"""")
            .find(json)?.groupValues?.getOrNull(1)?.replace("\\n", " ")?.trim()
    }

    fun stopListening() {
        try { speechService?.stop() } catch (_: Exception) { }
        speechService = null
        listening = false
    }

    fun release() {
        stopListening()
        try { model?.close() } catch (_: Exception) { }
        model = null
    }
}
