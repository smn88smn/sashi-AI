#!/usr/bin/env bash
set -euo pipefail

MODEL_URL="https://alphacephei.com/vosk/models/vosk-model-small-fa-0.42.zip"
WORK_DIR="${TMPDIR:-/tmp}/sashi-vosk"
MODEL_DIR="app/src/main/assets/model-fa"

mkdir -p "$WORK_DIR/unpacked" "$(dirname "$MODEL_DIR")"
curl -fL --retry 3 --retry-delay 2 "$MODEL_URL" -o "$WORK_DIR/model.zip"
unzip -q -o "$WORK_DIR/model.zip" -d "$WORK_DIR/unpacked"

SOURCE_DIR="$(find "$WORK_DIR/unpacked" -mindepth 1 -maxdepth 1 -type d -name 'vosk-model-small-fa-*' -print -quit)"
if [[ -z "$SOURCE_DIR" || ! -f "$SOURCE_DIR/am/final.mdl" || ! -d "$SOURCE_DIR/conf" ]]; then
  echo "ERROR: Persian Vosk model archive is incomplete or has an unexpected structure." >&2
  exit 1
fi

rm -rf "$MODEL_DIR"
mkdir -p "$MODEL_DIR"
cp -R "$SOURCE_DIR"/. "$MODEL_DIR"/
test -s "$MODEL_DIR/am/final.mdl"
test -f "$MODEL_DIR/conf/model.conf"
echo "Persian Vosk model installed at $MODEL_DIR"
